from django.apps import AppConfig


class CounsellorAgentConfig(AppConfig):
    name = 'counsellor_agent'
