from django.contrib import admin
from .models import CollegeModel

# Register your models here.

admin.site.register(CollegeModel)