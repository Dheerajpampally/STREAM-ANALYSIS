from django.apps import AppConfig


class ExamConfig(AppConfig):
    name = 'exam'
